# HEMMA — Customer Decision Log

Companion to the in-app **Business Decisions** screen (`/business-decisions`), which is the
source of truth and lets the customer filter live during the meeting. This file is for
post-meeting follow-up and written sign-off.

## APPROVED

*(Nothing is marked approved yet — this section fills in as the customer confirms items below.)*

## NEEDS DECISION

- **Booking confirmation** — Instant vs. Trainer Approval
- **Cancellation deadline** — 24h / 12h before session / no deadline
- **Reschedule deadline** — same as cancellation, or custom
- **No-show policy** — charge full session / partial fee / no penalty
- **Payment gateway** — which provider (Stripe, a local Qatar gateway, or both)
- **Refund rules** — full / partial (pro-rated) / none after session start
- **Trainer payout timing** — after session / weekly / monthly
- **Group training** — Phase 1 or Phase 2
- **Habit coaching** — Phase 1 or Phase 2
- **Body assessment report analysis method** — manual review / automated extraction / AI-assisted
- **Body assessment data retention** — how long, and who can access it
- **Kids training** — launch with guardian-consent flow in Phase 1, or later

## PROPOSED (awaiting confirmation)

- **Platform commission** — 20%
- **Trainer share** — 80%
- **Trainer cancellation policy** — auto full refund or trainer proposes a new slot
- **Online training** — included in Phase 1
- **Trainer access to subscriber measurements** — full read access with consent, or summary only
- **Progress photos** — optional and private (current assumption)

## FUTURE (not in Phase 1 scope)

- Nutrition coaching
- Wearables integration (Apple Health, Garmin, Fitbit)
- Video calls / live coaching
- Marketplace, Trainer Store, Healthy Food, Healthy Gifting, Partners
- Challenges & Rewards (preview only in this prototype)
- AI workout assistant, community/social feed

---

*Update this file as decisions are confirmed in customer meetings — move items between sections
and note the date/decision-maker for the record.*
