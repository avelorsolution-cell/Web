package com.avelorsolutions.hemma.prototype;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
