import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.avelorsolutions.hemma.prototype',
  appName: 'HEMMA',
  webDir: 'dist',
}

export default config
